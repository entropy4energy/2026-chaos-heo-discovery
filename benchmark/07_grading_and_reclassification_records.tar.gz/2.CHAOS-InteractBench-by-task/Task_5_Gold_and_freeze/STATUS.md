# Task 5 — Build gold answers and freeze the data state

**Status: PARTIAL — the freeze is done, the two-expert gold construction is not**


## Done

- Snapshot taken 2026-08-16T22:51:25Z with `snapshot_id` chaos-snapshot-20260816-225125Z.
- Raw `?schema` (103,228 bytes) and `?help` (8,679 bytes) fetched directly, not through the MCP server, and stored as raw bytes with full HTTP metadata.
- SHA-256 recorded for both; `snapshots/manifest.csv` written.
- Ten sentinel queries archived; drift checked during the run window and reported no change in schema hash or sentinel AUID sets.
- 49 gold queries archived, each with the exact summons, full URL, HTTP status, response byte length, response SHA-256 and the resolved AUID list. The 11 tasks without a gold query are the abstention tasks, where the correct answer is a refusal and no query applies.

## Not done

- **Gold was not built by two independent experts.** The protocol requires Expert A and Expert B to author AFLUX independently, then an adjudicator to resolve differences using only the prompt and snapshot. Gold here was generated from the intent spec and verified by execution against the live API. It is checkable — every gold record carries a URL and response hash — but it is not dual-expert adjudicated.
- No `chaos-interactbench-v1.0-gold` tag was created.
- `gold/` was not made read-only to the run account.
- No institutional or secure cloud backup copy was made.
