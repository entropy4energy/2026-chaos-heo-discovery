# Task 9 — Conduct the expert blinded evaluation

**Status: INFRASTRUCTURE READY — no ratings collected yet**


## Done

- 94 blinded answer cards built: 30 tasks x 3 systems, plus 4 duplicates for within-rater consistency.
- Task subset drawn stratified by expected_status with the master seed BEFORE any outcome was inspected, so the subset cannot flatter a system.
- One answer per (task, system), always repetition 1, so no cherry-picking.
- Model names, system ids, provider names, tool names and timing stripped; full scientific content preserved.
- Four per-expert packets, each in a different card order.
- Blinding key encrypted with a one-time passphrase stored nowhere in the repository.
- `unblind_review.py` refuses to decrypt without a locked ratings export.

## Not done

- **No ratings have been collected.** Four experts are required; none have rated.
- 3 systems rather than the protocol's 5, because S4/S5 produced no data. 94 cards against the protocol's 150 per expert.
- This is the only component of the protocol designed to measure whether answers are scientifically useful rather than merely correct against gold. Its absence is why the current results support claims about grounded retrieval accuracy and not about usefulness to a materials scientist.
- Scope as specified: 4 experts x 150 answer cards (30 tasks x 5 systems) in two sessions, with ICC(2,k) and Krippendorff alpha for reliability, and an encrypted blinding key opened only after data lock.
- It needs people, not compute.
