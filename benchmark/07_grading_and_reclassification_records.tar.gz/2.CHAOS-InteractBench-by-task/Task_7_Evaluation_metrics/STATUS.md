# Task 7 — Compute evaluation metrics

**Status: SUBSTANTIALLY COMPLETE**


## Done

- Grounded Task Success implemented as the conjunction V AND C AND R AND P AND H.
- One scored row per run, with a `detail` block recording why each component passed or failed.
- Aggregation to one row per (model, system, task) without discarding repetitions.
- AUIDs verified against the LIVE API rather than against gold, so a real record that is not the gold answer scores incorrect on R but is not counted as a fabrication.
- Error taxonomy computed structurally from the authored summons, because CHAOS returns a bare HTTP 400 with an empty body for every rejection — text matching classified 100% as `other`.
- Efficiency metrics: tokens, executed vs authored queries, repair counts, wall time.
- Runs stopped by a harness limit score `null` and are excluded, never scored zero.

## Not done

- `claims_audit.csv` reports `undetermined` for claims from runs executed before the runner was fixed to store AUID lists: those records kept `auid_count` but not the identifiers, so whether a specific claim appeared in that run's own response cannot be recovered from the record alone. `make_metric_tables.py --verify` re-fetches each archived URL and uses it as evidence only when the response SHA-256 still matches what was stored at run time.
- Unit accuracy is not scored as an independent dimension.
- nDCG and rank-correlation metrics (7.4) are not computed; ranking tasks may be unsatisfiable as specified because AFLUX has no sort capability.
