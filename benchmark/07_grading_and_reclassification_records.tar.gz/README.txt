Original scored tables contain 1,020 run IDs. scoring_guard_changes.csv is a later 6-row guard/reclassification record and is not silently substituted into the original tables.
