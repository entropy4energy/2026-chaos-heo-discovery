# CHAOS-Agent Results Revision Package

本文件夹是基于现有 `CHAOS-InteractBench` 结果生成的独立交付副本。原始 benchmark 文件夹和 Dropbox manuscript 文件夹均未被覆盖或修改。

## 交付内容

- `manuscript_revision/manuscript.pdf`：已编译的 30 页修订稿；正文 Figure 8 已替换为定量 benchmark 主图，Results 中已加入独立的 CHAOS-Agent 小节。
- `latex/chaos_agent_results.tex`：可单独审阅或移植的 Results 小节。
- `latex/chaos_agent_si_figures.tex`、`latex/chaos_agent_summary_table.tex`：SI 图与汇总表的 LaTeX 片段。
- `latex/figure_captions.txt`：正文与 SI 图注的纯文本版本。
- `figures/main/`：Figure 8 综合图及四个独立子图，均含 PNG 和矢量 PDF。
- `figures/SI/`：Figure S3--S6 及定量 SI 子图，均含 PNG 和 PDF。
- `scripts/plot_*.py`：每个程序只分析并输出一个子图。
- `processing_notes/`：每个子图的公式、分母、筛选规则、置信区间和限制说明。
- `data/xlsx/`：每个子图对应的 Excel 绘图数据；各文件包含 `PlotData` 与 `ReadMe` 工作表。
- `data/originpro/`：可直接导入 OriginPro 2024 的平面 CSV worksheet。
- `DATA_AUDIT.md` 与 `data/scoring_guard_changes.csv`：数据完整性和空回答评分修正记录。

## 主要结果的解释边界

主结果采用计划运行数作为分母：需要数据库记录的 49 个任务各运行 3 次。CHAOS live-access 条件中 52/147（35.4%）通过全部自动检查；无数据库工具与仅提供静态说明的条件均为 0/147。这里的“通过”只表示满足既定自动检查，不等同于专家确认答案具有完整科学价值。

当前数据没有实验人员评分、完成时间或使用体验量表，因此稿件没有声称节省实验时间、提升易用性或改善实验决策。GPT reference 使用不同的命令行 agent loop，因此只作为探索性参照，不构成严格受控的模型排名。

## 重新生成图表

在本机环境中，从本文件夹运行：

```bash
python3 scripts/plot_fig8a_interaction.py
python3 scripts/plot_fig8b_controlled_access.py
python3 scripts/plot_fig8c_backbones.py
python3 scripts/plot_fig8d_query_steps.py
python3 scripts/plot_figS5a_execution_limits.py
python3 scripts/plot_figS5b_correct_refusal.py
python3 scripts/plot_figS6_sensitivity.py
python3 scripts/assemble_figures.py
```

脚本默认从 `BENCHMARK_ROOT` 读取数据。若 benchmark 被移动，可设置 `CHAOS_BENCHMARK_ROOT`。Excel 文件由随 Codex 工作区提供的 `@oai/artifact-tool` 生成；如 Node runtime 位置改变，可设置 `CHAOS_ARTIFACT_NODE`。

## Figure 编号安排

- 正文 Figure 8：新生成的定量 CHAOS-Agent benchmark 综合图。
- Figure S3：用户提供的 `PIC_SI3.pdf`，展示当前 CHAOS-Agent workflow。
- Figure S4：原正文 Figure 8，明确标为较早期的界面/检索路线示意，不作为 benchmark 证据。
- Figure S5：运行完成度与应拒答问题。
- Figure S6：live-access 效应的敏感性分析。

## 已知但不影响本次新增内容的问题

修订稿可成功编译，且没有未解析的交叉引用或引用。LaTeX 日志仅保留原稿既有的 Table S1 高度警告（`SI.tex` 第 164 行，超出 24.6866 pt）；该表不是本次新增内容。
