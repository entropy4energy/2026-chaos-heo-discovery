# CHAOS-InteractBench data audit

## Files inspected

- Raw run JSON records: 1,452 files and 1,452 unique `run_id` values under `Task_6_Execute_runs`.
- Released tidy run table: 1,442 rows and 1,442 unique `run_id` values in `Task_7_Evaluation_metrics/runs_tidy.csv`.
- Ten raw ablation runs are absent from the released tidy table. They are listed below and were not reconstructed or used in any figure.

```text
HEO-R-010-A__A3__r1
HEO-R-010-A__A4__r1
HEO-R-011-A__A1__r1
HEO-R-011-A__A2__r1
HEO-R-011-A__A3__r1
HEO-R-011-A__A4__r1
HEO-R-012-A__A1__r1
HEO-R-012-A__A2__r1
HEO-R-012-A__A3__r1
HEO-R-012-A__A4__r1
```

Because the available ablation derivative mixes present and missing repetitions, no ablation panel or numerical claim was added. This avoids filling gaps with inferred or fabricated values.

## Minimal output-presence guard

Seventeen rows in `runs_tidy.csv` have released `gts = 1` although the corresponding raw JSON has an empty `final_answer`. Several component checks can be vacuously true when an answer contains no claim. All generated analyses therefore use:

```text
GTS_guarded = GTS_reported x I(trim(final_answer) is not empty)
```

Only those 17 released passes are changed to failures. Their exact identities are recorded in `data/scoring_guard_changes.csv`. This guard does not otherwise rescore answer content.

The primary S1-versus-S2 result for data-retrieval tasks remains 52/147 versus 0/147. Displayed values affected by the guard include the Glimmer live-access first-run result (5/49 rather than 6/49) and the primary live-access correct-refusal result (2/33 rather than 7/33).

## Claim boundaries

- “Passed every automated check” means the run satisfied the benchmark's executable-query, constraint, result, identifier, and reporting-status checks and produced a non-empty answer.
- The benchmark does not contain expert ratings of scientific usefulness, ease of use, experimental time saved, or decision quality.
- Property values and units were not independently revalidated by a human expert in this analysis.
- The GPT reference used a different command-line agent loop and is not interpreted as a controlled backbone ranking.
- The benchmark exercises an instrumented implementation of the same three read-only functions; claims are limited to live CHAOS access through this evaluated setup.
