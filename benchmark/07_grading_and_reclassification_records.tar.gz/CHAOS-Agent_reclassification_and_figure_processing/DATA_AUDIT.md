# CHAOS-InteractBench data audit

## Files inspected

- Raw run JSON records: 1,020 files and 1,020 unique `run_id` values under `Task_6_Execute_runs`.
- Released tidy run table: 1,020 rows and 1,020 unique `run_id` values in `Task_7_Evaluation_metrics/runs_tidy.csv`, one for each raw run.

## Minimal output-presence guard

Six rows in `runs_tidy.csv` have released `gts = 1` although the corresponding raw JSON has an empty `final_answer`. Several component checks can be vacuously true when an answer contains no claim. All generated analyses therefore use:

```text
GTS_guarded = GTS_reported x I(trim(final_answer) is not empty)
```

Only those six released passes are changed to failures. Their exact identities are recorded in `data/scoring_guard_changes.csv`. This guard does not otherwise rescore answer content.

The primary S1-versus-S2 result for data-retrieval tasks remains 52/147 versus 0/147. Displayed values affected by the guard include the Glimmer live-access first-run result (5/49 rather than 6/49) and the primary live-access correct-refusal result (2/33 rather than 7/33).

## Claim boundaries

- “Passed every automated check” means the run satisfied the benchmark's executable-query, constraint, result, identifier, and reporting-status checks and produced a non-empty answer.
- The benchmark does not contain expert ratings of scientific usefulness, ease of use, experimental time saved, or decision quality.
- Property values and units were not independently revalidated by a human expert in this analysis.
- The GPT reference used a different command-line agent loop and is not interpreted as a controlled backbone ranking.
- The benchmark exercises an instrumented implementation of the same three read-only functions; claims are limited to live CHAOS access through this evaluated setup.
