Existing scripts only. No scoring was rerun to create this archive. The score_runs.py header contains legacy protocol language; use the recorded locked task files and Task_7 status to interpret the actual run set.

2026-10-05: score_runs.py checks the AUIDs in answers against auid_existence_2026-08.tsv (next to it; pass --auid-table) instead of the live CHAOS API, which now needs a key. With the table it reproduces every recorded P and H. See the deviations log of the preregistration.
