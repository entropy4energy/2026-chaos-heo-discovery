#!/usr/bin/env python3
"""Score CHAOS-InteractBench runs against protocol 7.2.

    GTS_i = 1 iff V == C == R == P == H == 1

    V  Executable query behavior  every required query valid by the final
                                  attempt, or the task correctly requires none
    C  Constraint fidelity        required/excluded/numeric/structural/sorting/
                                  limit constraints match the gold state
    R  Result correctness         AUID set, ordering, status, values satisfy
                                  the task-specific gold criteria
    P  Provenance completeness    every reported material/value links to a
                                  retrieved AUID and record
    H  No unsupported claims      nothing contradicts or exceeds the evidence

WHAT THIS SCORER DOES AND DOES NOT DECIDE
V, P and H are derivable from the run record plus a live AUID check, so they are
computed here. C is computed from `gold_constraints` in the task file. R needs
the dual-expert adjudicated gold answer (the AUID set and expected values),
which does not exist until the 120 locked tasks are written - so R is emitted as
`null`, and any run with R unresolved gets `gts: null`, never `0`. Scoring a
missing gold as a failure would silently manufacture a result.

Three rules below come from the 2026-08-17 pilot and are not obvious:

1. AUIDs are verified against what CHAOS served when the benchmark ran,
   never against the sentinel subset. Sentinels cover two queries; a
   legitimate AUID from any other query falls outside them, and diffing
   against them reports FALSE hallucinations. The scorer of record reads
   snapshots/auid_existence_2026-08.tsv: every AUID the benchmark names (gold,
   sentinels, model answers) and whether the CHAOS API served it during the
   benchmark. The live API is no longer the reference: it needs a key since
   2026-09-27, and supercell records leave the public view in October 2026, so
   a live check would call real AUIDs fabricated (preregistration, deviations
   log, 2026-10-05). An AUID missing from the table is unchecked (null), never
   false. --live checks against the API instead, for new runs.
2. S3 (static one-shot) never sees its query's results, so its answer cannot
   contain a real AUID. Scoring S3 on answer content gives it 0 by
   construction. For S3 the scored artifact is the runner-executed query plus
   whether the model's ASSERTED status matches what that query actually
   returned - which is where the fabricated-verification signal lives.
3. A run flagged `output_truncated_before_content` is a harness/budget outcome,
   not a wrong answer. It scores `null`, not 0.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parent.parent
CHAOS_BASE_URL = "https://s4e.ai/API/chaos/"
# The AUIDs the benchmark names and whether CHAOS served them during the benchmark (rule 1).
AUID_TABLE = ROOT / "snapshots" / "auid_existence_2026-08.tsv"
# CHAOS returns 403 to requests without a User-Agent - found the hard way.
USER_AGENT = "CHAOS-InteractBench/1.0"

AUID_RE = re.compile(r"s4e:[0-9a-f]+")
# A complete AUID: 16 hex digits. Anything shorter (a cut-off "s4e:2") cannot be a CHAOS record.
AUID_FULL_RE = re.compile(r"s4e:[0-9a-f]{16}")
STATUS_RE = re.compile(r'"status"\s*:\s*"(\w+)"')
# A summons directive: name, optionally with parenthesised args.
DIRECTIVE_RE = re.compile(r"([a-z_]+)(?:\(([^)]*)\))?")


class AuidVerifier:
    """AUID existence checks (rule 1 of the module docstring).

    mode "table"   (default) the frozen table of what CHAOS served during the benchmark;
                   an AUID the table does not list is unknown (None), never False.
    mode "live"    the CHAOS API, with the key from CHAOS_API_KEY or ~/.aflow/chaos_api_key;
                   only an empty answer counts as False, any other failure is unknown.
    mode "offline" no checks; every AUID is unknown.
    """

    def __init__(self, mode: str = "table", table: Path = AUID_TABLE, client: Any = None):
        if mode not in {"table", "live", "offline"}:
            raise ValueError(f"unknown AUID check mode {mode!r}")
        self.mode = mode
        self.cache: dict[str, bool] = {}
        self.client = client
        if mode == "table":
            self.cache = load_auid_table(table)
        elif mode == "live" and client is None:
            import httpx  # only the live mode needs it
            headers = {"User-Agent": USER_AGENT}
            key = chaos_api_key()
            if key:
                headers["X-API-Key"] = key
            self.client = httpx.Client(timeout=30.0, headers=headers)

    def exists(self, auid: str) -> bool | None:
        if not AUID_FULL_RE.fullmatch(auid):
            return False  # not an AUID at all, so no record can carry it
        if self.mode == "offline":
            return None
        if auid in self.cache:
            return self.cache[auid]
        if self.mode == "table":
            return None  # not in the table: unchecked, never false
        try:
            r = self.client.get(f"{CHAOS_BASE_URL}?auid({auid}),format(json)")
            if r.status_code != 200:
                return None  # refused or failed (no key, rate limit, outage): unknown, not false
            body = r.json()
        except Exception:
            return None  # unknown, not false - never call an outage a hallucination
        if not isinstance(body, list):
            return None
        self.cache[auid] = bool(body)
        return self.cache[auid]


def load_auid_table(path: Path) -> dict[str, bool]:
    """auid -> served, from the frozen table (tab-separated: auid, served, supercell)."""
    out: dict[str, bool] = {}
    with open(path) as fh:
        header = fh.readline().rstrip("\n").split("\t")
        if header[:2] != ["auid", "served"]:
            raise ValueError(f"{path}: unexpected header {header}")
        for n, line in enumerate(fh, 2):
            cols = line.rstrip("\n").split("\t")
            if len(cols) < 2 or not AUID_FULL_RE.fullmatch(cols[0]) or cols[1] not in {"true", "false"}:
                raise ValueError(f"{path}:{n}: bad row {line!r}")
            if cols[0] in out:
                raise ValueError(f"{path}:{n}: {cols[0]} listed twice")
            out[cols[0]] = cols[1] == "true"
    return out


def chaos_api_key() -> str:
    """CHAOS API key from CHAOS_API_KEY or ~/.aflow/chaos_api_key, as AFLOW reads it."""
    import os
    key = os.environ.get("CHAOS_API_KEY", "").strip()
    if key:
        return key
    path = Path.home() / ".aflow" / "chaos_api_key"
    return path.read_text().strip() if path.is_file() else ""


def parse_summons(summons: str) -> dict[str, list[str]]:
    """Directive -> list of argument strings. Bare directives map to []."""
    out: dict[str, list[str]] = {}
    if not summons:
        return out
    for name, args in DIRECTIVE_RE.findall(summons):
        out.setdefault(name, [])
        if args:
            out[name].extend(a.strip() for a in args.split(",") if a.strip())
    return out


def authored_queries(rec: dict) -> list[dict]:
    """Every summons the model WROTE, including ones the budget never dispatched."""
    return [t for t in rec.get("tool_calls", []) if t.get("name") == "chaos_query"]


def executed_queries(rec: dict) -> list[dict]:
    """Only the summonses actually sent to CHAOS.

    When `max_semantic_tool_calls` is reached the runner still records the
    summons the model authored, with `status_code` null and no latency - that
    provenance is worth keeping. But such a query never reached the API and
    never informed the answer, so scoring V (executable query behaviour) or C
    (constraint fidelity of the final summons) against it charges the model for
    a query the harness refused to run. A transport failure IS an execution -
    the request left the process - so it stays in this list.
    """
    out = []
    for t in authored_queries(rec):
        if t.get("status_code") is not None or t.get("error"):
            out.append(t)
    return out


def score_V(rec: dict, task: dict) -> tuple[int, dict]:
    """Executable query behavior."""
    qs = executed_queries(rec)
    detail: dict[str, Any] = {"n_queries": len(qs)}
    expects_none = task.get("expected_status") in {"clarification_needed", "property_unavailable"}

    if not qs:
        detail["reason"] = "no query executed"
        return (1 if expects_none else 0), detail

    detail["first_query_valid"] = qs[0].get("status_code") == 200
    detail["first_query_http_status"] = qs[0].get("status_code")
    final = qs[-1]
    detail["final_query_valid"] = final.get("status_code") == 200
    detail["final_query_http_status"] = final.get("status_code")
    detail["budget_exceeded"] = any(q.get("budget_exceeded") for q in qs)
    return (1 if final.get("status_code") == 200 else 0), detail


def score_C(rec: dict, task: dict) -> tuple[int | None, dict]:
    """Constraint fidelity: model's final summons vs gold_constraints."""
    gold = task.get("gold_constraints") or {}
    qs = executed_queries(rec)
    if not qs:
        # For a task whose correct behaviour is to issue NO query (ambiguity to
        # clarify, property that does not exist), not querying satisfies
        # constraint fidelity vacuously - there are no constraints to get wrong.
        # Returning None here left otherwise-complete runs permanently blocked
        # on C even when V/R/P/H were all resolved.
        if task.get("expected_status") in {"clarification_needed", "property_unavailable"}:
            return (1, {"reason": "task correctly requires no query"})
        return (None, {"reason": "no query to compare"})
    summons = qs[-1].get("model_authored") or qs[-1].get("executed") or ""
    parsed = parse_summons(summons)
    detail: dict[str, Any] = {"summons": summons, "parsed": parsed}
    ok = True

    got_species = {s.upper() for s in parsed.get("species", [])}
    want_species = {s.upper() for s in (gold.get("required_species") or [])}
    if want_species:
        detail["species_required"] = sorted(want_species)
        detail["species_got"] = sorted(got_species)
        if not want_species <= got_species:
            ok = False
            detail["species_missing"] = sorted(want_species - got_species)

    excluded = {s.upper() for s in (gold.get("excluded_species") or [])}
    if excluded & got_species:
        ok = False
        detail["excluded_species_present"] = sorted(excluded & got_species)

    # paging() per the frozen help: paging(J) = page J at the default size of
    # 64; paging(J,K) = page J of size K; paging(0) / paging(-0) = ALL results.
    # paging(J) alone is therefore VALID syntax - it just does not express
    # "the first N", which is what a limit constraint requires. An earlier
    # version of this scorer marked any paging without two arguments as
    # malformed; that was wrong and would have penalised valid queries.
    if gold.get("limit") is not None:
        pg = parsed.get("paging", [])
        detail["paging_args"] = pg
        want = int(gold["limit"])
        if not pg:
            ok = False
            detail["paging_absent"] = True
        else:
            try:
                nums = [int(x) for x in pg]
            except ValueError:
                ok = False
                detail["paging_nonnumeric"] = True
                nums = []
            if nums:
                if nums[0] == 0:
                    # Documented as "all results" - the opposite of a limit.
                    ok = False
                    detail["paging_returns_all"] = True
                elif len(nums) == 1:
                    ok = False
                    detail["paging_no_size"] = {"page": nums[0], "default_size": 64,
                                                "required_limit": want}
                elif nums[1] != want:
                    ok = False
                    detail["paging_count_mismatch"] = (nums[1], want)

    # Bare property projection (`,compound,auid,`) returns HTTP 400 - only the
    # parenthesised form (`compound(*)`) is accepted. The FROZEN HELP documents
    # the bare form in its own worked example, so a system grounded only in that
    # help is actively misled. Flagged, not scored: it is an invalid-query
    # cause that belongs to component V, and duplicating it in C would
    # double-penalise one mistake.
    bare = [d for d, a in parsed.items()
            if not a and d not in {"paging", "format", "catalog", "help", "schema"}]
    if bare:
        detail["bare_projections"] = bare

    return (1 if ok else 0), detail


def score_R(rec: dict, task: dict) -> tuple[int | None, dict]:
    """Result correctness.

    An ABSENT `gold_auids` means the task has not been adjudicated -> None.
    An EMPTY `gold_auids: []` is a real gold answer: the correct result is *no
    records*, which is the whole point of the no-data and abstention tasks
    (R3/R10/R12, DEV-T4). Treating empty as missing left 7.3's no-data accuracy
    silently unscored - the one metric those tasks exist to produce.
    """
    if "gold_auids" not in task or task["gold_auids"] is None:
        return (None, {"reason": "no adjudicated gold AUID set for this task"})

    got = AUID_RE.findall(rec.get("final_answer") or "")
    want = list(task["gold_auids"])
    detail = {"gold_n": len(want), "got_n": len(got)}

    if not want:
        # Correct behaviour is to report none. Any AUID here is either invented
        # or irrelevant; either way the result is wrong.
        detail["expects_no_records"] = True
        return (1 if not got else 0), detail

    if task.get("ordering_matters"):
        return (1 if got[: len(want)] == want else 0), detail
    return (1 if set(want) <= set(got) else 0), detail


def score_P_H(rec: dict, task: dict, verifier: AuidVerifier) -> tuple[int | None, int | None, dict]:
    """Provenance completeness and no-unsupported-claims."""
    answer = rec.get("final_answer") or ""
    claimed = AUID_RE.findall(answer)
    qs = executed_queries(rec)
    retrieved_ok = any(q.get("status_code") == 200 for q in qs)
    detail: dict[str, Any] = {"auids_claimed": len(claimed), "unique": len(set(claimed))}

    asserted = STATUS_RE.search(answer)
    detail["asserted_status"] = asserted.group(1) if asserted else None

    # The fabricated-verification check: asserting success when nothing succeeded.
    if detail["asserted_status"] in {"verified", "partial"} and not retrieved_ok:
        detail["asserted_success_without_evidence"] = True
        return 0, 0, detail

    if not claimed:
        # No identifiers claimed: provenance is vacuously complete and nothing
        # exceeds the evidence. An honest refusal lands here.
        detail["reason"] = "no AUIDs claimed"
        return 1, 1, detail

    if not retrieved_ok:
        detail["auids_without_any_successful_query"] = True
        return 0, 0, detail

    unverified, unknown = [], []
    for a in set(claimed):
        ok = verifier.exists(a)
        if ok is None:
            unknown.append(a)
        elif not ok:
            unverified.append(a)
    detail["auids_not_in_chaos"] = unverified
    detail["auids_unchecked"] = unknown

    if unverified:
        return 0, 0, detail          # fabricated identifiers
    if unknown:
        return None, None, detail    # could not check - not a failure
    return 1, 1, detail


# --------------------------------------------------------------------------
# Efficiency (7.9) and repair (7.3) metrics
# --------------------------------------------------------------------------

# Normalised error classes for 7.3's error taxonomy. Matched against the API's
# own diagnostic text, which is stable ("ERROR 14 Invalid function in query: X").
# Normalised error classes for 7.3's error taxonomy.
#
# An earlier version matched the API's diagnostic text on the assumption that
# it returns bodies like "ERROR 14 Invalid function in query: X". Measured
# across 5 backbones and 344 queries, CHAOS returns a bare HTTP 400 with an
# EMPTY body for every rejection - so text matching put 100% of failures in
# "other" and the taxonomy carried no information. Classification is therefore
# structural: it reads the summons the model authored.
#
# All three dominant classes are documentation-induced, which is the finding:
#   bare_projection         - the frozen help's own example uses `compound,auid`,
#                             which the API rejects (SWEEP-FINDINGS 1a).
#   numeric_double_wildcard - `compound(*FeO*)` is valid (string substring);
#                             `enthalpy_formation_atom(*-1000*)` is a 400. The
#                             help does not say the form is string-only.
#   sort_unsupported        - AFLUX has no sort()/order(); the help does not say so.
_DIRECTIVE = re.compile(r"^\s*([A-Za-z_][A-Za-z0-9_]*)\s*\((.*)\)\s*$", re.S)
# Properties whose values are numeric, so substring wildcards do not apply.
# Anything not listed is treated as string-like, which is the safe direction:
# it under-reports numeric_double_wildcard rather than inventing it.
_STRING_PROPS = {"compound", "auid", "aurl", "species", "spacegroup_relax",
                 "spacegroup_orig", "prototype", "catalog", "format", "paging"}


def _split_top(summons: str) -> list[str]:
    """Split on commas that are not inside parentheses."""
    out, depth, cur = [], 0, ""
    for ch in summons or "":
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth = max(0, depth - 1)
        if ch == "," and depth == 0:
            out.append(cur); cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur)
    return [x for x in (t.strip() for t in out) if x]


def classify_error(text: str, summons: str = "") -> str | None:
    """Classify a failed query. `text` is kept for transport-level failures."""
    t = (text or "").lower()
    if "timeout" in t or "timed out" in t:
        return "transport_timeout"
    if "connect" in t or "readerror" in t or "remote protocol" in t:
        return "transport_error"

    frags = _split_top(summons)
    if any(f.lower().startswith(("sort(", "order(")) or f.lower() in ("sort", "order")
           for f in frags):
        return "sort_unsupported"
    if any("(" not in f for f in frags):
        return "bare_projection"
    for f in frags:
        m = _DIRECTIVE.match(f)
        if not m:
            continue
        prop, val = m.group(1).lower(), m.group(2).strip()
        if prop in _STRING_PROPS:
            continue
        if len(val) > 1 and val.startswith("*") and val.endswith("*"):
            return "numeric_double_wildcard"
    return "other" if (t or summons) else None


def efficiency(rec: dict) -> dict:
    """7.9 efficiency plus 7.3 repair metrics.

    Cost here is TOKENS AND CALLS, deliberately not a currency estimate: the
    self-hosted systems have no per-token price, so a dollar figure would only
    be meaningful for the commercial comparator and would not compare across
    arms. Report the physical quantities and let the paper price them.
    """
    u = rec.get("usage") or {}
    authored = authored_queries(rec)
    qs = executed_queries(rec)
    blocked = len(authored) - len(qs)
    frozen = [t for t in rec.get("tool_calls", []) if t.get("source") == "frozen_snapshot"]
    tool_ms = sum((t.get("latency_ms") or 0) for t in qs)
    wall = rec.get("wall_time_s") or 0.0

    out = {
        "prompt_tokens": u.get("prompt_tokens"),
        "completion_tokens": u.get("completion_tokens"),
        "total_tokens": u.get("total_tokens"),
        "model_calls": u.get("model_calls"),
        "semantic_tool_calls": rec.get("semantic_tool_calls"),
        "schema_help_calls": len(frozen),
        "wall_time_s": wall,
        "tool_time_s": round(tool_ms / 1000, 2),
        # Model time is wall minus time spent waiting on CHAOS. It is an upper
        # bound - harness overhead is folded in - so report it as such.
        "model_time_s_upper": round(max(0.0, wall - tool_ms / 1000), 2),
        "reasoning_chars": sum(x.get("chars", 0) for x in (rec.get("reasoning") or [])),
        "truncated_tool_outputs": rec.get("truncated_tool_outputs", 0),
        # Summonses the model wrote after the budget closed. Kept separate:
        # they show intent but never reached CHAOS, so they cannot be scored
        # as valid or invalid queries.
        "queries_authored": len(authored),
        "queries_executed": len(qs),
        "queries_blocked_by_budget": blocked,
    }

    # 7.3 repair metrics. Executed queries only - see executed_queries().
    if qs:
        first = qs[0]
        out["first_query_valid"] = first.get("status_code") == 200
        out["first_query_http_status"] = first.get("status_code")
        out["first_query_error_class"] = (
            None if first.get("status_code") == 200
            else classify_error(first.get("error") or "",
                                first.get("model_authored") or ""))
        out["error_classes"] = [
            classify_error(q.get("error") or "", q.get("model_authored") or "")
            for q in qs if q.get("status_code") != 200]
        valid_idx = next((i for i, q in enumerate(qs) if q.get("status_code") == 200), None)
        out["final_query_valid"] = qs[-1].get("status_code") == 200
        out["final_query_index"] = valid_idx
        # A repair is a model-initiated retry AFTER a failed query, not every
        # extra call: a complex task legitimately issues several VALID queries
        # and must not be scored as if it were repairing.
        repairs = 0
        for prev, cur in zip(qs, qs[1:]):
            if prev.get("status_code") != 200:
                repairs += 1
        out["semantic_repair_count"] = repairs
        out["distinct_summons"] = len({q.get("model_authored") for q in qs})
    else:
        out |= {"first_query_valid": None, "final_query_valid": None,
                "semantic_repair_count": 0, "distinct_summons": 0,
                "error_classes": []}
    return out


def score_run(rec: dict, task: dict, verifier: AuidVerifier) -> dict:
    out: dict[str, Any] = {
        "run_id": rec.get("run_id"),
        "task_id": rec.get("task_id"),
        "system": rec.get("system"),
        "access": rec.get("access"),
        "repetition": rec.get("repetition"),
        "stop_reason": rec.get("stop_reason"),
        "wall_time_s": rec.get("wall_time_s"),
        "semantic_tool_calls": rec.get("semantic_tool_calls"),
        "truncated_tool_outputs": rec.get("truncated_tool_outputs", 0),
        "efficiency": efficiency(rec),
    }

    # Budget/harness outcomes are not model failures (see module docstring).
    if rec.get("error") in {"output_truncated_before_content", "wall_time_exceeded",
                            "infrastructure_retries_exhausted"}:
        out.update({"V": None, "C": None, "R": None, "P": None, "H": None,
                    "gts": None, "excluded_reason": rec["error"]})
        return out

    V, vd = score_V(rec, task)
    C, cd = score_C(rec, task)
    R, rd = score_R(rec, task)
    P, H, phd = score_P_H(rec, task, verifier)
    out.update({"V": V, "C": C, "R": R, "P": P, "H": H,
                "detail": {"V": vd, "C": cd, "R": rd, "PH": phd}})

    comps = [V, C, R, P, H]
    # GTS requires ALL five to be 1, so a single definitive 0 settles the run
    # regardless of what is unknown - a hard failure dominates a null. Only
    # block when nothing has failed and something is still unresolved.
    # (Without this, every tool-free arm sat unscored on a missing C: it never
    # issues a query, so there is no summons to compare against gold, even
    # though it had already failed V outright.)
    if any(c == 0 for c in comps):
        out["gts"] = 0
        unresolved = [n for n, c in zip("VCRPH", comps) if c is None]
        if unresolved:
            out["gts_decided_despite_unresolved"] = unresolved
    elif any(c is None for c in comps):
        out["gts"] = None
        out["gts_blocked_by"] = [n for n, c in zip("VCRPH", comps) if c is None]
    else:
        out["gts"] = 1
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="Score CHAOS-InteractBench runs (protocol 7.2).")
    ap.add_argument("--runs", type=Path, required=True)
    ap.add_argument("--tasks", type=Path, default=ROOT / "tasks")
    ap.add_argument("--out", type=Path, default=None, help="Write metrics_by_run.jsonl here")
    ap.add_argument("--offline", action="store_true", help="Skip AUID verification")
    ap.add_argument("--live", action="store_true",
                    help="Check AUIDs against the CHAOS API (key from CHAOS_API_KEY or ~/.aflow/chaos_api_key) "
                         "instead of the frozen table of what CHAOS served during the benchmark")
    ap.add_argument("--auid-table", type=Path, default=AUID_TABLE, help="Frozen AUID table (default: %(default)s)")
    args = ap.parse_args()

    tasks = {}
    for tf in sorted(args.tasks.glob("*.yaml")):
        if tf.name.startswith("._"):
            continue
        t = yaml.safe_load(tf.read_text())
        tasks[t["task_id"]] = t
    if not tasks:
        raise SystemExit(f"no task files in {args.tasks}")

    if args.offline and args.live:
        raise SystemExit("--offline and --live exclude each other")
    verifier = AuidVerifier("offline" if args.offline else "live" if args.live else "table", table=args.auid_table)
    rows = []
    for rf in sorted(args.runs.glob("*.json")):
        rec = json.loads(rf.read_text())
        task = tasks.get(rec.get("task_id"))
        if task is None:
            print(f"  skip {rf.name}: no task file for {rec.get('task_id')}", file=sys.stderr)
            continue
        rows.append(score_run(rec, task, verifier))

    hdr = f"{'run':<30}{'V':>3}{'C':>3}{'R':>3}{'P':>3}{'H':>3}{'GTS':>6}  note"
    print(hdr); print("-" * len(hdr))
    def cell(x): return "-" if x is None else str(x)
    for r in rows:
        note = r.get("excluded_reason") or (
            "blocked:" + "".join(r.get("gts_blocked_by", [])) if r.get("gts") is None else "")
        rid = (r["run_id"] or "").replace("DEV-T", "T").replace("-001-A__", "_")
        print(f"{rid:<30}{cell(r.get('V')):>3}{cell(r.get('C')):>3}{cell(r.get('R')):>3}"
              f"{cell(r.get('P')):>3}{cell(r.get('H')):>3}{cell(r.get('gts')):>6}  {note}")

    scored = [r for r in rows if r.get("gts") is not None]
    print(f"\nruns={len(rows)}  scoreable={len(scored)}  "
          f"GTS=1: {sum(1 for r in scored if r['gts'] == 1)}")
    if len(scored) < len(rows):
        print("NOTE: unscoreable runs are `null`, never 0 - see module docstring.")

    if args.out:
        args.out.write_text("\n".join(json.dumps(r) for r in rows))
        print(f"wrote {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
