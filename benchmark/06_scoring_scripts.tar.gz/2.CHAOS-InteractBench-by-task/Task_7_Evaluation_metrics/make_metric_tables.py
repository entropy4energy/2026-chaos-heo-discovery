#!/usr/bin/env python3
"""Materialise the protocol's metric tables (7.10) as Parquet, plus a claims audit.

metrics_by_run.parquet        one row per run, every primary/secondary/diagnostic metric
metrics_by_task_system.parquet aggregated per (system, task) WITHOUT discarding runs -
                               mean, median, majority success and variability across reps
claims_audit.csv              one row per factual claim, with whether the archived
                              response that run actually received supports it

The claims audit is built from the run records rather than from gold: protocol 7.6 scores
a claim as supported only when the response THAT RUN received contains the matching AUID.
A gold record does not support a claim the model never retrieved.
"""
from __future__ import annotations
import argparse, csv, json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent


def load_metrics(paths):
    rows = []
    for p in paths:
        if not p.exists():
            continue
        arm = p.parent.name
        for line in p.read_text().splitlines():
            if not line.strip():
                continue
            r = json.loads(line)
            eff = r.pop("efficiency", {}) or {}
            det = r.pop("detail", {}) or {}
            flat = {**r, **{f"eff_{k}": v for k, v in eff.items()}}
            flat["arm_dir"] = arm
            flat["detail_json"] = json.dumps(det)
            rows.append(flat)
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", type=Path, default=ROOT / "derived")
    ap.add_argument("--verify", action="store_true",
                    help="re-fetch archived URLs and use them as evidence only "
                         "when the response hash still matches")
    a = ap.parse_args()
    a.out.mkdir(parents=True, exist_ok=True)

    paths = sorted(ROOT.glob("runs/*/metrics.jsonl")) + sorted(ROOT.glob("runs/*/*/metrics.jsonl"))
    df = load_metrics(paths)
    if df.empty:
        raise SystemExit("no metrics.jsonl found")

    # error_classes is a list; Parquet is happier with a joined string
    if "eff_error_classes" in df:
        df["eff_error_classes"] = df["eff_error_classes"].apply(
            lambda v: ";".join(v) if isinstance(v, list) else (v or ""))

    df["canonical_intent_id"] = df["task_id"].astype(str).str.rsplit("-", n=1).str[0]
    f1 = a.out / "metrics_by_run.parquet"
    df.to_parquet(f1, index=False)
    print(f"  metrics_by_run.parquet         {len(df):>5} rows x {len(df.columns)} cols")

    # aggregate without discarding runs
    num = [c for c in ("gts", "V", "C", "R", "P", "H", "eff_total_tokens",
                       "eff_queries_executed", "eff_wall_time_s", "eff_semantic_repair_count")
           if c in df.columns]
    g = df.groupby(["system", "task_id"], dropna=False)
    agg = g[num].agg(["mean", "median", "std", "count"])
    agg.columns = [f"{a_}_{b}" for a_, b in agg.columns]
    # majority success across repetitions - the protocol's paired-test unit
    agg["gts_majority"] = g["gts"].apply(
        lambda s: float(s.dropna().mean() > 0.5) if s.dropna().size else float("nan"))
    agg["gts_any"] = g["gts"].apply(
        lambda s: float(s.dropna().max()) if s.dropna().size else float("nan"))
    agg["gts_all"] = g["gts"].apply(
        lambda s: float(s.dropna().min()) if s.dropna().size else float("nan"))
    agg = agg.reset_index()
    agg["canonical_intent_id"] = agg["task_id"].astype(str).str.rsplit("-", n=1).str[0]
    f2 = a.out / "metrics_by_task_system.parquet"
    agg.to_parquet(f2, index=False)
    print(f"  metrics_by_task_system.parquet {len(agg):>5} rows x {len(agg.columns)} cols")

    # Claims audit (7.6). A claim is supported only when the response THAT RUN
    # received contains the AUID. Runs executed before 2026-08-20 stored auid_count
    # but not the identifiers, so support cannot be determined from the record alone;
    # those rows are marked "undetermined" rather than silently counted as supported.
    # --verify re-fetches each archived URL and uses the response ONLY when its
    # SHA-256 still matches the hash stored at run time, so a database change cannot
    # be mistaken for evidence.
    import re
    verified_auids: dict[str, set[str]] = {}
    if a.verify:
        import hashlib, httpx
        urls = {}
        for rp in sorted(ROOT.glob("runs/**/*.json")):
            if rp.name == "manifest.json":
                continue
            try:
                rec = json.loads(rp.read_text())
            except Exception:
                continue
            for t in rec.get("tool_calls", []):
                if t.get("status_code") == 200 and t.get("url") and t.get("sha256"):
                    urls[t["url"]] = t["sha256"]
        print(f"  re-fetching {len(urls)} archived URLs to verify evidence…")
        ok = drift = 0
        with httpx.Client(timeout=180, headers={"User-Agent": "CHAOS-InteractBench/1.0"}) as c:
            for i, (u, h) in enumerate(urls.items(), 1):
                try:
                    resp = c.get(u)
                except Exception:
                    continue
                if hashlib.sha256(resp.content).hexdigest() != h:
                    drift += 1
                    continue
                try:
                    parsed = resp.json()
                except Exception:
                    continue
                if isinstance(parsed, list):
                    verified_auids[u] = {r["auid"] for r in parsed
                                         if isinstance(r, dict) and r.get("auid")}
                    ok += 1
                if i % 200 == 0:
                    print(f"    {i}/{len(urls)}  verified={ok} drifted={drift}")
        print(f"  evidence recovered for {ok} URLs; {drift} responses no longer match "
              f"their archived hash and were NOT used")

    claim_rows = []
    for rp in sorted(ROOT.glob("runs/**/*.json")):
        if rp.name == "manifest.json":
            continue
        try:
            rec = json.loads(rp.read_text())
        except Exception:
            continue
        if "run_id" not in rec:
            continue
        retrieved, have_evidence = set(), False
        for t in rec.get("tool_calls", []):
            if isinstance(t.get("auids"), list):
                retrieved |= set(t["auids"]); have_evidence = True
            elif t.get("url") in verified_auids:
                retrieved |= verified_auids[t["url"]]; have_evidence = True
        fa = rec.get("final_answer")
        text = fa if isinstance(fa, str) else json.dumps(fa or "")
        for c in sorted(set(re.findall(r"s4e:[0-9a-f]{16}", text))):
            claim_rows.append({
                "run_id": rec["run_id"], "system": rec.get("system"),
                "task_id": rec.get("task_id"), "claim_type": "auid", "claim": c,
                "supported": (str(c in retrieved).lower() if have_evidence else "undetermined"),
            })
    if claim_rows:
        f3 = a.out / "claims_audit.csv"
        with open(f3, "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=list(claim_rows[0]))
            w.writeheader(); w.writerows(claim_rows)
        from collections import Counter
        c = Counter(r["supported"] for r in claim_rows)
        print(f"  claims_audit.csv               {len(claim_rows):>5} AUID claims  {dict(c)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
